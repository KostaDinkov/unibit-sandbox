﻿namespace _3.Shapes
{
    public class IsoscelesTriangle : Triangle, IIsosceles
    {
        public override string GetShapeType()
        {
            return "Isosceles Triangle";
        }
    }
}