﻿namespace _3.Shapes
{
    public class Square : Rectangle
    {
        public override string GetShapeType()
        {
            return "Square";
        }
    }
}