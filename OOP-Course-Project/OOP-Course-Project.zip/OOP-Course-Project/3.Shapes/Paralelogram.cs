﻿namespace _3.Shapes
{
    public class Parallelogram : Quadrilateral
    {
        public override string GetShapeType()
        {
            return "Parallelogram";
        }
    }
}