﻿namespace _3.Shapes
{
    public class EquilateralTriangle : IsoscelesTriangle
    {
        public override string GetShapeType()
        {
            return "Equilateral Triangle";
        }
    }
}