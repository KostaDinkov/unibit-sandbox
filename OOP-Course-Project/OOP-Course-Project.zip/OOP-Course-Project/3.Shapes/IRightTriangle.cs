﻿namespace _3.Shapes
{
    public interface IRightTriangle
    {
        public double GetHypotenuseLength();
    }
}