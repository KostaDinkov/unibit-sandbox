﻿namespace _3.Shapes
{
    internal interface IIsosceles
    {
    }
}