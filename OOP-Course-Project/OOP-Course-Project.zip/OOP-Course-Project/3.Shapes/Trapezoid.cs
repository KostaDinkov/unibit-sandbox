﻿namespace _3.Shapes
{
    public class Trapezoid : Quadrilateral
    {
        public override string GetShapeType()
        {
            return "Trapezoid";
        }
    }
}