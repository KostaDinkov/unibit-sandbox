﻿namespace _3.Shapes
{
    public class Triangle : Polygon
    {
        public override string GetShapeType()
        {
            return "Triangle";
        }
    }
}