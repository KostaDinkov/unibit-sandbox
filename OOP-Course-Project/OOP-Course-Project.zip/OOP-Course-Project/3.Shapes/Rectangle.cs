﻿namespace _3.Shapes
{
    public class Rectangle : Parallelogram
    {
        public override string GetShapeType()
        {
            return "Rectangle";
        }
    }
}