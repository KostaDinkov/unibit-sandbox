﻿namespace _3.Shapes
{
    public class Quadrilateral : Polygon
    {
        public override string GetShapeType()
        {
            return "Quadrilateral";
        }
    }
}