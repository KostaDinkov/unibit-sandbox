﻿public enum PartCategory
{
    Engine,
    Tires,
    Exhaust,
    Suspention,
    Brakes
}